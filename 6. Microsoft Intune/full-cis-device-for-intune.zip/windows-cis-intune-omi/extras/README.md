To make working with Intune profiles easier in Firefox:
1. Install the "Stylus" extension
2. Import the stylesheet into your configuration
